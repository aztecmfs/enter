import type { Metadata } from 'next'
import Link from 'next/link'
import { PageHeading } from '@/components/page-heading'

export const metadata: Metadata = {
  title: 'VATSIM',
  description:
    'Enter Air Virtual Airlines operates exclusively on the VATSIM network, flying with live air traffic control and real pilots.',
}

const facts = [
  {
    title: 'Live air traffic control',
    body: 'Our flights are handled by real people on frequency, from clearance delivery to arrival.',
  },
  {
    title: 'Real routes, real traffic',
    body: 'We fly the routes Enter Air flies, together with the rest of the VATSIM community.',
  },
  {
    title: 'One network only',
    body: 'EAVA operations take place exclusively on VATSIM. An active VATSIM account is required.',
  },
]

export default function VatsimPage() {
  return (
    <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-16 lg:px-12 lg:py-20">
      <PageHeading title="VATSIM" subtitle="Where we fly" />

      <div className="mt-9 max-w-2xl space-y-5 text-[0.95rem] leading-[1.8] text-foreground/85 sm:text-base">
        <p>
          Enter Air Virtual Airlines operates on VATSIM, the Virtual Air Traffic Simulation Network.
          It is a free, worldwide network where virtual pilots and virtual air traffic controllers
          meet in the same sky.
        </p>
        <p>
          Flying on VATSIM is what makes our operations feel real: clearances, radar vectors,
          holdings and busy frequencies all come from people, not from a script.
        </p>
      </div>

      <ul className="mt-14 grid gap-y-10 border-t border-line pt-12 lg:grid-cols-3 lg:gap-x-8 lg:gap-y-0">
        {facts.map((fact, index) => (
          <li
            key={fact.title}
            className={index === 0 ? 'lg:pr-8' : 'lg:border-l lg:border-line lg:px-8'}
          >
            <h2 className="font-display text-sm font-bold uppercase tracking-[0.09em] text-brand">
              {fact.title}
            </h2>
            <p className="mt-3 max-w-[22rem] text-sm leading-[1.75] text-muted-foreground">
              {fact.body}
            </p>
          </li>
        ))}
      </ul>

      <div className="mt-14 flex flex-wrap items-center gap-4">
        <a
          href="https://vatsim.net"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center bg-brand px-8 py-4 font-display text-sm font-bold uppercase tracking-[0.1em] text-white transition-colors hover:bg-brand-dark"
        >
          Visit vatsim.net
        </a>
        <Link
          href="/how-to-join"
          className="font-display text-xs font-bold uppercase tracking-[0.09em] text-brand underline-offset-4 hover:underline"
        >
          How to join EAVA
        </Link>
      </div>
    </div>
  )
}
