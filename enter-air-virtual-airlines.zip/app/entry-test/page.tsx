import type { Metadata } from 'next'
import Link from 'next/link'
import {
  Clock,
  FileText,
  MessageSquare,
  RefreshCw,
  Shuffle,
  Trophy,
  type LucideIcon,
} from 'lucide-react'
import { PageHeading } from '@/components/page-heading'

export const metadata: Metadata = {
  title: 'Entry Test',
  description:
    'Every applicant to Enter Air Virtual Airlines must pass the Entry Test: 25 questions, 20 multiple-choice and 5 open, with a minimum score of 20/25 and 4/5 on the open questions.',
}

type Feature = { icon: LucideIcon; title: string; body: string }

const features: Feature[] = [
  {
    icon: FileText,
    title: 'Knowledge',
    body: 'Questions about VATSIM, aviation and EAVA operations.',
  },
  {
    icon: Shuffle,
    title: 'Randomized',
    body: 'Questions are drawn randomly from a large database.',
  },
  {
    icon: Clock,
    title: 'Time limited',
    body: 'You have a limited amount of time to complete the test.',
  },
  {
    icon: Trophy,
    title: 'Passing score',
    body: 'A minimum score is required to pass the test.',
  },
  {
    icon: MessageSquare,
    title: 'Open questions',
    body: 'Some questions require your own words, not just single answers.',
  },
  {
    icon: RefreshCw,
    title: 'One chance',
    body: 'You have one attempt. Prepare well!',
  },
]

const structure = [
  { value: '25', label: 'Questions in total' },
  { value: '20', label: 'Multiple-choice questions' },
  { value: '5', label: 'Open-ended questions' },
  { value: '25', label: 'Points maximum (1 per question)' },
]

export default function EntryTestPage() {
  return (
    <>
      <section className="mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-16 lg:px-12 lg:py-20">
        <div className="grid gap-12 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)] lg:gap-16">
          <div>
            <PageHeading title="Entry Test" />
            <p className="mt-9 max-w-md text-[0.95rem] leading-[1.8] text-foreground/85 sm:text-base">
              Before joining Enter Air Virtual Airlines every applicant must successfully complete
              the Entry Test. It confirms that you understand VATSIM, basic airline operations and
              the way we fly at EAVA.
            </p>
          </div>

          <ul className="grid gap-x-10 gap-y-9 sm:grid-cols-2 lg:border-l lg:border-line lg:pl-14">
            {features.map((feature) => (
              <li key={feature.title} className="flex gap-4">
                <feature.icon
                  aria-hidden
                  className="mt-0.5 size-7 shrink-0 text-brand"
                  strokeWidth={1.75}
                />
                <div>
                  <h2 className="font-display text-sm font-bold uppercase tracking-[0.09em] text-brand">
                    {feature.title}
                  </h2>
                  <p className="mt-2 text-sm leading-[1.7] text-muted-foreground">{feature.body}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section aria-labelledby="structure-heading" className="border-y border-line bg-secondary">
        <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8 lg:px-12 lg:py-16">
          <h2
            id="structure-heading"
            className="font-display text-sm font-bold uppercase tracking-[0.12em] text-ink"
          >
            Test structure
          </h2>

          <ul className="mt-8 grid grid-cols-2 gap-y-8 lg:grid-cols-4">
            {structure.map((item) => (
              <li key={item.label}>
                <p className="font-display text-4xl font-bold text-brand sm:text-5xl">
                  {item.value}
                </p>
                <p className="mt-2 max-w-[12rem] font-display text-[0.7rem] font-semibold uppercase tracking-[0.09em] text-muted-foreground">
                  {item.label}
                </p>
              </li>
            ))}
          </ul>

          <div className="mt-12 grid gap-8 border-t border-line pt-10 sm:grid-cols-2 lg:gap-16">
            <div>
              <h3 className="font-display text-sm font-bold uppercase tracking-[0.12em] text-ink">
                Pass requirements
              </h3>
              <p className="mt-4 text-sm leading-[1.8] text-muted-foreground">
                Both conditions must be satisfied at the same time. Meeting only one of them is not
                a pass.
              </p>
            </div>

            <dl className="space-y-6">
              <div className="flex items-baseline justify-between gap-6 border-b border-line pb-4">
                <dt className="font-display text-xs font-semibold uppercase tracking-[0.09em] text-ink">
                  Overall score
                </dt>
                <dd className="font-display text-xl font-bold text-brand">
                  20 / 25 <span className="text-sm font-semibold text-muted-foreground">(80%)</span>
                </dd>
              </div>
              <div className="flex items-baseline justify-between gap-6 border-b border-line pb-4">
                <dt className="font-display text-xs font-semibold uppercase tracking-[0.09em] text-ink">
                  Open questions
                </dt>
                <dd className="font-display text-xl font-bold text-brand">
                  4 / 5 <span className="text-sm font-semibold text-muted-foreground">(80%)</span>
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 text-center sm:px-8 lg:px-12">
        <button
          type="button"
          disabled
          aria-describedby="test-availability"
          className="inline-flex items-center gap-4 bg-brand px-9 py-4 font-display text-sm font-bold uppercase tracking-[0.1em] text-white transition-colors disabled:cursor-not-allowed disabled:opacity-60"
        >
          <FileText aria-hidden className="size-4" />
          Start Entry Test
        </button>

        <p id="test-availability" className="mt-5 text-xs text-muted-foreground">
          The test platform is being prepared. By starting the test you accept the{' '}
          <Link href="/how-to-join" className="text-brand underline underline-offset-2">
            Entry Test rules
          </Link>
          .
        </p>
      </section>
    </>
  )
}
