import type { Metadata } from 'next'
import { Clock, Mail, MessageSquare } from 'lucide-react'
import { ContactForm } from '@/components/contact-form'
import { PageHeading } from '@/components/page-heading'
import { site } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Contact',
  description:
    'Get in touch with the Enter Air Virtual Airlines team about membership, the Entry Test or the community.',
}

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-16 lg:px-12 lg:py-20">
      <PageHeading title="Contact" subtitle="Talk to the EAVA team" />

      <div className="mt-12 grid gap-14 lg:grid-cols-[minmax(0,0.75fr)_minmax(0,1.25fr)] lg:gap-20">
        <div>
          <p className="text-[0.95rem] leading-[1.8] text-foreground/85 sm:text-base">
            Questions about joining, the Entry Test or our operations? Send us a message and a member
            of the staff team will get back to you.
          </p>

          <ul className="mt-10 space-y-8">
            <li className="flex gap-4">
              <Mail aria-hidden className="mt-0.5 size-5 shrink-0 text-brand" strokeWidth={1.75} />
              <div>
                <h2 className="font-display text-xs font-bold uppercase tracking-[0.1em] text-ink">
                  Email
                </h2>
                <a
                  href={`mailto:${site.email}`}
                  className="mt-1 block text-sm text-brand underline-offset-4 hover:underline"
                >
                  {site.email}
                </a>
              </div>
            </li>
            <li className="flex gap-4">
              <MessageSquare
                aria-hidden
                className="mt-0.5 size-5 shrink-0 text-brand"
                strokeWidth={1.75}
              />
              <div>
                <h2 className="font-display text-xs font-bold uppercase tracking-[0.1em] text-ink">
                  Community
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Day-to-day conversation happens on our Discord server. An invite is sent to every
                  pilot who passes the Entry Test.
                </p>
              </div>
            </li>
            <li className="flex gap-4">
              <Clock aria-hidden className="mt-0.5 size-5 shrink-0 text-brand" strokeWidth={1.75} />
              <div>
                <h2 className="font-display text-xs font-bold uppercase tracking-[0.1em] text-ink">
                  Response time
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  EAVA is run by volunteers in their spare time. Please allow a few days for a
                  reply.
                </p>
              </div>
            </li>
          </ul>
        </div>

        <div className="border-t border-line pt-10 lg:border-t-0 lg:border-l lg:pt-0 lg:pl-20">
          <ContactForm />
        </div>
      </div>
    </div>
  )
}
