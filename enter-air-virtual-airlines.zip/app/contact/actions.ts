'use server'

export type ContactState = {
  status: 'idle' | 'success' | 'error'
  message: string
  errors?: Partial<Record<'name' | 'email' | 'subject' | 'message', string>>
}

export const initialContactState: ContactState = { status: 'idle', message: '' }

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

/**
 * Validates and accepts a contact request.
 * Delivery (email or database storage) is intentionally not wired up yet -
 * plug a mailer or a database integration in here later.
 */
export async function submitContact(
  _prev: ContactState,
  formData: FormData,
): Promise<ContactState> {
  const name = String(formData.get('name') ?? '').trim()
  const email = String(formData.get('email') ?? '').trim()
  const subject = String(formData.get('subject') ?? '').trim()
  const message = String(formData.get('message') ?? '').trim()

  const errors: ContactState['errors'] = {}
  if (name.length < 2) errors.name = 'Please enter your name.'
  if (!emailPattern.test(email)) errors.email = 'Please enter a valid email address.'
  if (subject.length < 3) errors.subject = 'Please add a short subject.'
  if (message.length < 20) errors.message = 'Please describe your message in at least 20 characters.'

  if (Object.keys(errors).length > 0) {
    return {
      status: 'error',
      message: 'Please correct the highlighted fields.',
      errors,
    }
  }

  console.log('[v0] contact request received from', email, '- subject:', subject)

  return {
    status: 'success',
    message: 'Thank you. Your message has been received - we usually reply within a few days.',
  }
}
