import type { Metadata } from 'next'
import Link from 'next/link'
import { PageHeading } from '@/components/page-heading'

export const metadata: Metadata = {
  title: 'How to Join',
  description:
    'Join Enter Air Virtual Airlines in four steps: learn about EAVA, complete the Entry Test, pass it, and become an EAVA pilot.',
}

const steps = [
  {
    number: '01',
    title: 'Learn about EAVA',
    body: 'Read who we are, how we fly and what we expect from our pilots.',
    href: '/about',
    linkLabel: 'About EAVA',
  },
  {
    number: '02',
    title: 'Complete the Entry Test',
    body: '25 questions covering VATSIM, aviation and EAVA operations.',
    href: '/entry-test',
    linkLabel: 'Entry Test details',
  },
  {
    number: '03',
    title: 'Pass the Entry Test',
    body: 'A minimum of 20/25 overall and 4/5 on the open questions is required.',
  },
  {
    number: '04',
    title: 'Join Enter Air Virtual Airlines',
    body: 'Receive your callsign, join the community and fly the line with us.',
  },
]

export default function HowToJoinPage() {
  return (
    <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-16 lg:px-12 lg:py-20">
      <PageHeading title="How to join" subtitle="Four steps to your callsign" />

      <p className="mt-9 max-w-xl text-[0.95rem] leading-[1.8] text-foreground/85 sm:text-base">
        Membership of Enter Air Virtual Airlines is free. All we ask is that you know the basics, fly
        with care and respect the community.
      </p>

      <ol className="mt-14 grid gap-y-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-y-0">
        {steps.map((step, index) => (
          <li
            key={step.number}
            className={
              index === 0
                ? 'lg:pr-8'
                : 'lg:border-l lg:border-line lg:px-8'
            }
          >
            <p className="font-display text-4xl font-bold text-brand/25 sm:text-5xl">
              {step.number}
            </p>
            <span aria-hidden className="mt-4 block h-[3px] w-10 bg-brand" />
            <h2 className="mt-5 font-display text-base font-bold uppercase tracking-[0.06em] text-ink">
              {step.title}
            </h2>
            <p className="mt-3 max-w-[17rem] text-sm leading-[1.75] text-muted-foreground">
              {step.body}
            </p>
            {step.href ? (
              <Link
                href={step.href}
                className="mt-4 inline-block font-display text-xs font-bold uppercase tracking-[0.09em] text-brand underline-offset-4 hover:underline"
              >
                {step.linkLabel}
              </Link>
            ) : null}
          </li>
        ))}
      </ol>

      <div className="mt-16 border-t border-line pt-12">
        <h2 className="font-display text-sm font-bold uppercase tracking-[0.12em] text-ink">
          Before you apply
        </h2>
        <ul className="mt-6 grid max-w-4xl gap-3 text-sm leading-[1.8] text-muted-foreground sm:grid-cols-2">
          <li>You need an active VATSIM account.</li>
          <li>You need a flight simulator and a working headset.</li>
          <li>You should be comfortable with basic IFR procedures.</li>
          <li>You fly for fun - EAVA is a hobby project, not a job.</li>
        </ul>

        <Link
          href="/entry-test"
          className="mt-10 inline-flex items-center gap-4 bg-brand px-8 py-4 font-display text-sm font-bold uppercase tracking-[0.1em] text-white transition-colors hover:bg-brand-dark"
        >
          Go to the Entry Test
        </Link>
      </div>
    </div>
  )
}
