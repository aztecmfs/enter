import { Hero } from '@/components/home/hero'
import { ValueStrip } from '@/components/home/value-strip'

export default function HomePage() {
  return (
    <>
      <Hero />
      <ValueStrip />
    </>
  )
}
