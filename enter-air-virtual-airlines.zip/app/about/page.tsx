import type { Metadata } from 'next'
import { Globe, Handshake, ShieldCheck, Target, type LucideIcon } from 'lucide-react'
import { BrandLogo } from '@/components/brand-logo'
import { PageHeading } from '@/components/page-heading'

export const metadata: Metadata = {
  title: 'About',
  description:
    'Enter Air Virtual Airlines is an independent hobby and community virtual airline recreating Enter Air operations on the VATSIM network.',
}

type Pillar = { icon: LucideIcon; title: string; body: string }

const pillars: Pillar[] = [
  {
    icon: ShieldCheck,
    title: 'Independent',
    body: 'EAVA is not affiliated with Enter Air. We are an independent virtual airline run by aviation enthusiasts.',
  },
  {
    icon: Target,
    title: 'Realism',
    body: 'We strive to replicate real-world operations with accurate procedures and high standards.',
  },
  {
    icon: Handshake,
    title: 'Respect',
    body: 'Respect, teamwork and professionalism are the foundation of our virtual airline.',
  },
  {
    icon: Globe,
    title: 'VATSIM',
    body: 'We are proud members of the VATSIM community and operate exclusively on the VATSIM network.',
  },
]

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-16 lg:px-12 lg:py-20">
      <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-start lg:gap-16">
        <div>
          <PageHeading title="About" subtitle="Enter Air Virtual Airlines" />

          <div className="mt-9 max-w-2xl space-y-5 text-[0.95rem] leading-[1.8] text-foreground/85 sm:text-base">
            <p>
              Enter Air Virtual Airlines (EAVA) is an independent virtual airline inspired by the
              real operations of Enter Air. It is a hobby and community project, created and run by
              aviation enthusiasts in their free time.
            </p>
            <p>
              Our goal is to recreate Enter Air operations in a virtual environment as realistically
              as possible, and to provide a professional flying experience for every virtual pilot
              who joins us.
            </p>
            <p>
              We operate on the VATSIM network, connecting pilots and air traffic controllers in a
              shared passion for aviation. EAVA is non-commercial: there is nothing to buy, and
              nothing to sell.
            </p>
            <p className="text-sm text-muted-foreground">
              EAVA is not a real airline and is not a branch, subsidiary, or official operating unit
              of Enter Air. All flying takes place inside flight simulators on the VATSIM network.
            </p>
          </div>
        </div>

        <div className="lg:pt-6">
          <BrandLogo asLink={false} className="h-16 w-auto sm:h-20 lg:h-24" />
        </div>
      </div>

      <hr className="mt-14 border-line sm:mt-16" />

      <ul className="grid grid-cols-1 gap-y-12 pt-12 sm:grid-cols-2 lg:grid-cols-4 lg:gap-y-0">
        {pillars.map((pillar, index) => (
          <li
            key={pillar.title}
            className={
              index === 0
                ? 'px-2 text-center lg:px-8'
                : 'px-2 text-center lg:border-l lg:border-line lg:px-8'
            }
          >
            <pillar.icon aria-hidden className="mx-auto size-8 text-brand" strokeWidth={1.75} />
            <h2 className="mt-4 font-display text-sm font-bold uppercase tracking-[0.09em] text-brand">
              {pillar.title}
            </h2>
            <p className="mx-auto mt-3 max-w-[16rem] text-sm leading-[1.7] text-muted-foreground">
              {pillar.body}
            </p>
          </li>
        ))}
      </ul>
    </div>
  )
}
