export const site = {
  name: 'Enter Air Virtual Airlines',
  shortName: 'EAVA',
  tagline: 'Real ops. Virtual skies.',
  email: 'contact@eava.org',
  discord: 'EAVA Community Discord',
  disclaimer:
    'Enter Air Virtual Airlines (EAVA) is a non-commercial, hobby and community project operating on the VATSIM network. It is not a real airline and is not affiliated with, endorsed by, or a branch, subsidiary or operating unit of Enter Air.',
} as const

export type NavItem = {
  label: string
  href: string
}

export const mainNav: NavItem[] = [
  { label: 'Home', href: '/' },
  { label: 'About', href: '/about' },
  { label: 'Entry Test', href: '/entry-test' },
  { label: 'How to Join', href: '/how-to-join' },
  { label: 'VATSIM', href: '/vatsim' },
  { label: 'Contact', href: '/contact' },
]
