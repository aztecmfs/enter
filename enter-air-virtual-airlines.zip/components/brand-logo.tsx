import Image from 'next/image'
import Link from 'next/link'
import { cn } from '@/lib/utils'

type BrandLogoProps = {
  className?: string
  /** Rendered as a link to the homepage when true. */
  asLink?: boolean
  priority?: boolean
}

/**
 * The official Enter Air Virtual Airlines logo.
 * The asset is used exactly as supplied - never recolour, redraw or restretch it.
 */
export function BrandLogo({ className, asLink = true, priority = false }: BrandLogoProps) {
  const image = (
    <Image
      src="/images/eava-logo.png"
      alt="Enter Air Virtual Airlines"
      width={1164}
      height={430}
      priority={priority}
      className={cn('h-14 w-auto select-none sm:h-16', className)}
    />
  )

  if (!asLink) return image

  return (
    <Link href="/" aria-label="Enter Air Virtual Airlines - home" className="inline-flex shrink-0">
      {image}
    </Link>
  )
}
