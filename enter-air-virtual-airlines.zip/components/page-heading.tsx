import { cn } from '@/lib/utils'

type PageHeadingProps = {
  title: string
  subtitle?: string
  className?: string
}

/** Sub-page heading: dark display title, blue sub-line, short blue rule. */
export function PageHeading({ title, subtitle, className }: PageHeadingProps) {
  return (
    <div className={cn('', className)}>
      <h1 className="font-display text-4xl font-bold uppercase leading-[1.05] tracking-[-0.01em] text-ink sm:text-5xl">
        {title}
      </h1>
      {subtitle ? (
        <p className="mt-2 font-display text-lg font-bold uppercase tracking-[0.01em] text-brand sm:text-xl">
          {subtitle}
        </p>
      ) : null}
      <span className="mt-6 block h-[3px] w-16 bg-brand" />
    </div>
  )
}
