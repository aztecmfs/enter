import Image from 'next/image'
import Link from 'next/link'
import { Plane } from 'lucide-react'
import { Swoosh } from '@/components/swoosh'

export function Hero() {
  return (
    <section className="relative isolate overflow-hidden bg-[#dbeaf7]">
      <Image
        src="/images/hero-wing.jpg"
        alt="View of an aircraft wing above the clouds during cruise"
        fill
        priority
        sizes="100vw"
        className="object-cover object-[70%_center]"
      />

      {/* left fade so the headline keeps the same contrast as the reference design */}
      <div
        aria-hidden
        className="absolute inset-0 bg-gradient-to-r from-white via-white/80 to-transparent sm:via-white/60 sm:to-40% lg:to-55%"
      />

      <div className="relative mx-auto flex min-h-[540px] max-w-7xl flex-col justify-center px-5 pt-16 pb-40 sm:min-h-[600px] sm:px-8 sm:pb-44 lg:min-h-[640px] lg:px-12 lg:pb-40">
        <div className="max-w-xl">
          <h1 className="font-display text-[2.75rem] font-bold uppercase leading-[0.98] tracking-[-0.015em] sm:text-6xl lg:text-[4.25rem]">
            <span className="block text-brand">Real ops.</span>
            <span className="block text-ink">Virtual skies.</span>
          </h1>

          <span aria-hidden className="mt-7 block h-[3px] w-16 bg-brand" />

          <p className="mt-7 max-w-md text-[0.95rem] leading-[1.75] text-foreground/85 sm:text-base">
            Enter Air Virtual Airlines is an independent, hobby-run virtual airline inspired by the
            real operations of Enter Air.
            <br />
            We bring realism, professionalism and passion to the virtual skies.
          </p>

          <Link
            href="/how-to-join"
            className="mt-9 inline-flex items-center gap-6 bg-brand px-8 py-4 font-display text-sm font-bold uppercase tracking-[0.1em] text-white shadow-sm transition-colors hover:bg-brand-dark"
          >
            Join EAVA
            <Plane aria-hidden className="size-4" />
          </Link>
        </div>
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 sm:h-28 lg:h-32">
        <Swoosh />
      </div>
    </section>
  )
}
