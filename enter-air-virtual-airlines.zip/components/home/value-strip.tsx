import { Gauge, Headphones, ShieldCheck, Users, type LucideIcon } from 'lucide-react'

type Value = {
  icon: LucideIcon
  title: string
  body: string
}

const values: Value[] = [
  {
    icon: Gauge,
    title: 'Realism',
    body: 'We replicate real-world operations with attention to every detail.',
  },
  {
    icon: ShieldCheck,
    title: 'Professionalism',
    body: 'High standards, clear procedures and a professional environment for every pilot.',
  },
  {
    icon: Users,
    title: 'Community',
    body: 'A global community of aviation enthusiasts sharing the same passion for flying.',
  },
  {
    icon: Headphones,
    title: 'VATSIM',
    body: 'Proudly operating on the VATSIM network. Fly real routes, with real pilots.',
  },
]

export function ValueStrip() {
  return (
    <section aria-label="What defines EAVA" className="bg-white">
      <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8 sm:py-16 lg:px-12">
        <ul className="grid grid-cols-1 gap-y-12 sm:grid-cols-2 lg:grid-cols-4 lg:gap-y-0">
          {values.map((value, index) => (
            <li
              key={value.title}
              className={
                index === 0
                  ? 'px-2 text-center lg:px-8'
                  : 'px-2 text-center sm:border-line lg:border-l lg:px-8'
              }
            >
              <value.icon aria-hidden className="mx-auto size-8 text-brand" strokeWidth={1.75} />
              <h2 className="mt-4 font-display text-sm font-bold uppercase tracking-[0.09em] text-brand">
                {value.title}
              </h2>
              <p className="mx-auto mt-3 max-w-[15rem] text-sm leading-[1.7] text-muted-foreground">
                {value.body}
              </p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
