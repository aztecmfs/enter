import { cn } from '@/lib/utils'

/**
 * The blue + grey sweep taken from the brand logo, used as the lower edge of the hero.
 * Rendered as SVG so it scales cleanly across breakpoints.
 */
export function Swoosh({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 1440 130"
      preserveAspectRatio="none"
      aria-hidden="true"
      focusable="false"
      className={cn('block h-full w-full', className)}
    >
      {/* white base below the sweep */}
      <path d="M0 112 C 420 96 960 56 1440 18 L1440 130 L0 130 Z" fill="#ffffff" />
      {/* grey sweep */}
      <path d="M0 112 C 420 96 960 56 1440 18 L1440 40 C 960 76 420 108 0 120 Z" fill="#9aa1a9" />
      {/* blue sweep */}
      <path d="M0 100 C 420 84 960 42 1440 0 L1440 26 C 960 64 420 96 0 110 Z" fill="var(--brand)" />
    </svg>
  )
}
