'use client'

import { useActionState } from 'react'
import { initialContactState, submitContact } from '@/app/contact/actions'

const fieldClass =
  'w-full border border-input bg-white px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-brand focus:ring-1 focus:ring-brand'

const labelClass =
  'block font-display text-[0.7rem] font-bold uppercase tracking-[0.1em] text-ink'

export function ContactForm() {
  const [state, formAction, pending] = useActionState(submitContact, initialContactState)

  return (
    <form action={formAction} className="space-y-6" noValidate>
      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className={labelClass}>
            Name
          </label>
          <input
            id="name"
            name="name"
            type="text"
            autoComplete="name"
            required
            aria-invalid={Boolean(state.errors?.name)}
            aria-describedby={state.errors?.name ? 'name-error' : undefined}
            className={`mt-2 ${fieldClass}`}
            placeholder="Jan Kowalski"
          />
          {state.errors?.name ? (
            <p id="name-error" className="mt-2 text-xs text-destructive">
              {state.errors.name}
            </p>
          ) : null}
        </div>

        <div>
          <label htmlFor="email" className={labelClass}>
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            aria-invalid={Boolean(state.errors?.email)}
            aria-describedby={state.errors?.email ? 'email-error' : undefined}
            className={`mt-2 ${fieldClass}`}
            placeholder="you@example.com"
          />
          {state.errors?.email ? (
            <p id="email-error" className="mt-2 text-xs text-destructive">
              {state.errors.email}
            </p>
          ) : null}
        </div>
      </div>

      <div>
        <label htmlFor="subject" className={labelClass}>
          Subject
        </label>
        <input
          id="subject"
          name="subject"
          type="text"
          required
          aria-invalid={Boolean(state.errors?.subject)}
          aria-describedby={state.errors?.subject ? 'subject-error' : undefined}
          className={`mt-2 ${fieldClass}`}
          placeholder="Entry Test question"
        />
        {state.errors?.subject ? (
          <p id="subject-error" className="mt-2 text-xs text-destructive">
            {state.errors.subject}
          </p>
        ) : null}
      </div>

      <div>
        <label htmlFor="message" className={labelClass}>
          Message
        </label>
        <textarea
          id="message"
          name="message"
          rows={6}
          required
          aria-invalid={Boolean(state.errors?.message)}
          aria-describedby={state.errors?.message ? 'message-error' : undefined}
          className={`mt-2 resize-y ${fieldClass}`}
          placeholder="Tell us how we can help."
        />
        {state.errors?.message ? (
          <p id="message-error" className="mt-2 text-xs text-destructive">
            {state.errors.message}
          </p>
        ) : null}
      </div>

      <div className="flex flex-wrap items-center gap-5">
        <button
          type="submit"
          disabled={pending}
          className="inline-flex items-center bg-brand px-8 py-4 font-display text-sm font-bold uppercase tracking-[0.1em] text-white transition-colors hover:bg-brand-dark disabled:opacity-60"
        >
          {pending ? 'Sending...' : 'Send message'}
        </button>

        <p aria-live="polite" className="text-sm text-muted-foreground">
          {state.status === 'success' ? (
            <span className="text-brand">{state.message}</span>
          ) : state.status === 'error' ? (
            <span className="text-destructive">{state.message}</span>
          ) : null}
        </p>
      </div>
    </form>
  )
}
