import Link from 'next/link'
import { Plane } from 'lucide-react'
import { mainNav, site } from '@/lib/site'

export function SiteFooter() {
  return (
    <footer className="mt-auto">
      <div className="border-t border-line bg-white">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 py-12 sm:px-8 lg:grid-cols-[1.4fr_1fr_1fr] lg:px-12">
          <div className="max-w-md">
            <p className="font-display text-sm font-bold uppercase tracking-[0.12em] text-brand">
              {site.name}
            </p>
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{site.disclaimer}</p>
          </div>

          <nav aria-label="Footer">
            <p className="font-display text-xs font-bold uppercase tracking-[0.12em] text-ink">
              Navigation
            </p>
            <ul className="mt-4 space-y-2.5">
              {mainNav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-brand"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <p className="font-display text-xs font-bold uppercase tracking-[0.12em] text-ink">
              Get in touch
            </p>
            <ul className="mt-4 space-y-2.5 text-sm text-muted-foreground">
              <li>
                <a href={`mailto:${site.email}`} className="transition-colors hover:text-brand">
                  {site.email}
                </a>
              </li>
              <li>
                <Link href="/contact" className="transition-colors hover:text-brand">
                  Contact form
                </Link>
              </li>
              <li>
                <a
                  href="https://vatsim.net"
                  target="_blank"
                  rel="noreferrer"
                  className="transition-colors hover:text-brand"
                >
                  vatsim.net
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-brand">
        <div className="mx-auto flex max-w-7xl items-center justify-center gap-4 px-5 py-4">
          <p className="tagline-track text-center font-display text-[0.6875rem] font-bold uppercase text-white sm:text-sm">
            Real ops. Virtual skies.
          </p>
          <span aria-hidden className="hidden h-px w-10 bg-white/60 sm:block" />
          <Plane aria-hidden className="hidden size-4 text-white sm:block" />
        </div>
      </div>
    </footer>
  )
}
