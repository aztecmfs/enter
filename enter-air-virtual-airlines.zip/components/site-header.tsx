'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'
import { BrandLogo } from '@/components/brand-logo'
import { mainNav } from '@/lib/site'
import { cn } from '@/lib/utils'

export function SiteHeader() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  useEffect(() => {
    setOpen(false)
  }, [pathname])

  const isActive = (href: string) => (href === '/' ? pathname === '/' : pathname.startsWith(href))

  return (
    <header className="relative z-30 border-b border-line/70 bg-white">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 sm:h-24 sm:px-8 lg:px-12">
        <BrandLogo priority />

        <nav aria-label="Main" className="hidden items-center gap-8 lg:flex xl:gap-10">
          {mainNav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={isActive(item.href) ? 'page' : undefined}
              className={cn(
                'relative py-1 font-display text-[0.8125rem] font-semibold uppercase tracking-[0.08em] transition-colors',
                isActive(item.href) ? 'text-brand' : 'text-ink hover:text-brand',
              )}
            >
              {item.label}
              {isActive(item.href) ? (
                <span className="absolute -bottom-1 left-0 h-[2px] w-full bg-brand" />
              ) : null}
            </Link>
          ))}

          <Link
            href="/how-to-join"
            className="bg-brand px-6 py-3 font-display text-[0.8125rem] font-bold uppercase tracking-[0.08em] text-white transition-colors hover:bg-brand-dark"
          >
            Join EAVA
          </Link>
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? 'Close menu' : 'Open menu'}
          className="inline-flex h-11 w-11 items-center justify-center text-ink transition-colors hover:text-brand lg:hidden"
        >
          {open ? <X className="size-6" aria-hidden /> : <Menu className="size-6" aria-hidden />}
        </button>
      </div>

      {open ? (
        <div id="mobile-nav" className="border-t border-line bg-white lg:hidden">
          <nav aria-label="Mobile" className="mx-auto flex max-w-7xl flex-col px-5 py-2 sm:px-8">
            {mainNav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive(item.href) ? 'page' : undefined}
                className={cn(
                  'flex items-center justify-between border-b border-line/70 py-4 font-display text-sm font-semibold uppercase tracking-[0.08em]',
                  isActive(item.href) ? 'text-brand' : 'text-ink',
                )}
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/how-to-join"
              className="mt-4 mb-4 bg-brand px-6 py-4 text-center font-display text-sm font-bold uppercase tracking-[0.08em] text-white"
            >
              Join EAVA
            </Link>
          </nav>
        </div>
      ) : null}
    </header>
  )
}
